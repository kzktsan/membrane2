-----------------------------------------------------------------------

  Image Filtering Software based on Nonlocal Foveated Self-Similarity
                Release ver. 1.12  (16 February 2012)

-----------------------------------------------------------------------

Copyright (c) 2011-2012 Tampere University of Technology. 
All rights reserved.
This work should be used for nonprofit purposes only.


Authors:                    Alessandro Foi
                            Giacomo Boracchi


web page:                   http://www.cs.tut.fi/~foi/FoveatedNL/


-----------------------------------------------------------------------
 Contents
-----------------------------------------------------------------------

The package implements the method(s) published in [1] and contains
the following files:

*) demo_FovNLM.m            : main demo script
*) FovNLM.m                 : Foveated NL-means denoising function
*) Man_fragment256.tif      : small image for running the demo
*) README.txt               : (this file)
*) LEGAL_NOTICE.txt         : legal information related to this files


-----------------------------------------------------------------------
 Requirements
-----------------------------------------------------------------------

*) Matlab ver. 6.5 or later


-----------------------------------------------------------------------
 Instructions
-----------------------------------------------------------------------

Instructions, syntax, and usage examples can be found in the comment
headers of the Matlab files.


-----------------------------------------------------------------------
 Change log
-----------------------------------------------------------------------

v1.12  (16 February 2012)
 + Improved comments and notation

v1.11  (13 February 2012)
 + Improved comments

v1.1   (8 February 2012)
 + Code optimization and first public release
 
v1.0  (28 December 2011) 
 + Minor fixes (padding etc.)

v0.9  (30 July 2011)
 + Initial code

-----------------------------------------------------------------------
 References
-----------------------------------------------------------------------

[1] A. Foi and G. Boracchi, "Foveated self-similarity in nonlocal image
    filtering", Proc. SPIE Electronic Imaging 2012, Human Vision and
    Electronic Imaging, 8291-32, Burlingame (CA), USA, January 2012.
 
 
-----------------------------------------------------------------------
 Disclaimer
-----------------------------------------------------------------------

Any unauthorized use of these routines for industrial or profit-
oriented activities is expressively prohibited. By downloading 
and/or using any of these files, you implicitly agree to all the 
terms of the TUT limited license, as specified in the document
Legal_Notice.txt (included in this package) and online at
http://www.cs.tut.fi/~foi/FoveatedNL/legal_notice.html


-----------------------------------------------------------------------
 Feedback
-----------------------------------------------------------------------

If you have any comment, suggestion, or question, please do
contact   Alessandro Foi  at  firstname.lastname@tut.fi


