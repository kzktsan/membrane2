%
%  Foveated Nonlocal Means denoising demo script  (ver 1.12)
%  Author:  Alessandro Foi, Tampere University of Technology, Finland
% --------------------------------------------------------------------------------
%
%  MAIN VARIABLES
%
%  y:               original image  (noise free), loaded from file
%  sigma :          standard deviation of the additive white Gaussian noise
%  z :              noisy image to be filtered
%  search_radius :  radius of search window     (e.g., 5 <= search_radius <= 13 )
%  U_radius :       radius of patch             (e.g., 1 <= U_radius <= 10)
%  disableFov :     disables foveation when set to 1  (optional)
%
%
%  This script demonstrates the use of the Foveated Nonlocal Means algorithm
%  implemented in the function  FovNLM.m
%
%
%  REFERENCE:
%  A. Foi and G. Boracchi, "Foveated self-similarity in nonlocal image filtering",
%  in Proc. IS&T/SPIE EI2012 - Human Vision and Electronic Imaging, January 2012.
%


clear


%% algorithm parameters
search_radius=10;  % (default 10)
U_radius=5;        % (default 5)




disp([' ']);
disp(['search_radius = ',num2str(search_radius),'    U_radius = ',num2str(U_radius)]);



%% check for SSIM
exists_ssim_file=exist('ssim_index','file');    % SSIM function can be downloaded from https://ece.uwaterloo.ca/~z70wang/research/ssim/



%% original image
y = double(imread('Man_fragment256.tif'));
y = y(100:200,100:200);

% more test images can be downloaded from http://www.cs.tut.fi/~foi/GCF-BM3D/BM3D_images.zip
% y = double(imread('image_Lena512.png'));

figure
imshow(y/255), title(['original image']);



%% noisy image
sigma=30;                   % noise standard deviation
z=y+sigma*randn(size(y));   % generate noisy observation with additive white Gaussian noise

PSNR_noisy = 10*log10(255^2/mean((y(:)-z(:)).^2));
string_to_display_noisy=['sigma = ',num2str(sigma), '  PSNRnoisy = ',num2str(PSNR_noisy),' db'];
if exists_ssim_file
    [mssim_noisy ssim_map] = ssim_index(y, z);
    string_to_display_noisy=[string_to_display_noisy,'  SSIMnoisy = ',num2str(mssim_noisy)];
end
disp( string_to_display_noisy )
figure
imshow(z/255), title(['noisy image:  ',string_to_display_noisy]);



%% Foveated NL-means
disp('Computing Foveated NL-means estimate (using foveated patch distance) ...');
tic
y_hat_FOV = FovNLM(z,search_radius,U_radius,sigma);
toc

PSNR_FOV = 10*log10(255^2/mean((y(:)-y_hat_FOV(:)).^2));
string_to_display_FOV=['PSNRfov = ',num2str(PSNR_FOV),' db'];

if exists_ssim_file
    [mssim_FOV ssim_map] = ssim_index(y, y_hat_FOV);
    string_to_display_FOV=[string_to_display_FOV,'  SSIMfov = ',num2str(mssim_FOV)];
end
disp( string_to_display_FOV )
figure
imshow(y_hat_FOV/255), title(['Foveated NL-means estimate:  ',string_to_display_FOV]);



%% standard NL-means for comparison
if 0
    disp('Computing standard NL-means estimate (using windowed patch distance) ...');
    tic
    disableFov=1;
    y_hat_WIN = FovNLM(z,search_radius,U_radius,sigma,disableFov);  % the last input disables foveation and the code will operate equivalent to the standard NL-means (with windowed patch distance).
    toc
    PSNR_WIN = 10*log10(255^2/mean((y(:)-y_hat_WIN(:)).^2));
    string_to_display_WIN=['PSNRwin = ',num2str(PSNR_WIN),' db'];
    if exists_ssim_file
        [mssim_WIN ssim_map] = ssim_index(y, y_hat_WIN);
        string_to_display_WIN=[string_to_display_WIN,'  SSIMfov = ',num2str(mssim_WIN)];
    end
    disp( string_to_display_WIN )
    figure
    imshow(y_hat_WIN/255), title(['standard NL-means estimate:  ',string_to_display_WIN]);
end

